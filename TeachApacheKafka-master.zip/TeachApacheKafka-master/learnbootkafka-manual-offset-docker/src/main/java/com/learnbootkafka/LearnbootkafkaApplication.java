package com.learnbootkafka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearnbootkafkaApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearnbootkafkaApplication.class, args);
	}
}
